package com.example.autocallrecorder;

import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.util.Log;

/**
 * BroadcastReceiver that listens for phone state changes and outgoing calls.
 * Starts/stops CallRecordingService accordingly.
 *
 * Handles:
 *  - PHONE_STATE: RINGING (incoming), OFFHOOK (in-call), IDLE (call ended)
 *  - NEW_OUTGOING_CALL: captures outgoing number
 *  - BOOT_COMPLETED: ensures receiver is active after reboot
 */
public class CallReceiver extends BroadcastReceiver {

    private static final String TAG = "CallReceiver";
    private static String lastState = TelephonyManager.EXTRA_STATE_IDLE;
    private static String outgoingNumber = null;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;

        String action = intent.getAction();
        Log.d(TAG, "Received action: " + action);

        // Capture outgoing call number before the call connects
        if (Intent.ACTION_NEW_OUTGOING_CALL.equals(action)) {
            outgoingNumber = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER);
            Log.d(TAG, "Outgoing call to: " + outgoingNumber);
            return;
        }

        // Handle boot completed - no action needed, receiver is auto-registered
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)) {
            Log.d(TAG, "Boot completed - CallReceiver is active");
            return;
        }

        // Handle phone state changes
        if (TelephonyManager.ACTION_PHONE_STATE_CHANGED.equals(action)) {
            String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);
            String incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);

            if (state == null) return;

            Log.d(TAG, "Phone state: " + state + " (was: " + lastState + ")");

            PreferencesManager prefs = new PreferencesManager(context);
            if (!prefs.isRecordingEnabled()) {
                Log.d(TAG, "Recording disabled by user — skipping");
                lastState = state;
                return;
            }

            if (TelephonyManager.EXTRA_STATE_OFFHOOK.equals(state) &&
                    !TelephonyManager.EXTRA_STATE_OFFHOOK.equals(lastState)) {
                // Call just connected (either outgoing picked up, or incoming answered)
                String number = (outgoingNumber != null) ? outgoingNumber : incomingNumber;
                String direction = (outgoingNumber != null) ? "OUTGOING" : "INCOMING";

                Log.d(TAG, "Call started - " + direction + " - " + number);
                startRecording(context, number, direction);

            } else if (TelephonyManager.EXTRA_STATE_IDLE.equals(state) &&
                    !TelephonyManager.EXTRA_STATE_IDLE.equals(lastState)) {
                // Call just ended
                Log.d(TAG, "Call ended - stopping recording");
                stopRecording(context);
                outgoingNumber = null;
            }

            lastState = state;
        }
    }

    private void startRecording(Context context, String number, String direction) {
        Intent serviceIntent = new Intent(context, CallRecordingService.class);
        serviceIntent.setAction(CallRecordingService.ACTION_START);
        serviceIntent.putExtra(CallRecordingService.EXTRA_PHONE_NUMBER, number);
        serviceIntent.putExtra(CallRecordingService.EXTRA_DIRECTION, direction);
        context.startService(serviceIntent);
    }

    private void stopRecording(Context context) {
        Intent serviceIntent = new Intent(context, CallRecordingService.class);
        serviceIntent.setAction(CallRecordingService.ACTION_STOP);
        context.startService(serviceIntent);
    }
}
