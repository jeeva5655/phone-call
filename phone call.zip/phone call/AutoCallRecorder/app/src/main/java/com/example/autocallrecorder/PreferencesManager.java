package com.example.autocallrecorder;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Manages persistent app preferences using SharedPreferences.
 */
public class PreferencesManager {

    private static final String PREF_NAME = "acr_prefs";
    private static final String KEY_RECORDING_ENABLED = "recording_enabled";

    private final SharedPreferences prefs;

    public PreferencesManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public boolean isRecordingEnabled() {
        return prefs.getBoolean(KEY_RECORDING_ENABLED, true); // Default: enabled
    }

    public void setRecordingEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_RECORDING_ENABLED, enabled).apply();
    }
}
