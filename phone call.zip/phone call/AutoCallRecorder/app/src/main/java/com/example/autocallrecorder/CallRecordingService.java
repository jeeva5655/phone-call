package com.example.autocallrecorder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Foreground service that manages the MediaRecorder for phone call audio.
 *
 * Audio source: VOICE_CALL (works on Android 5.0, requires both mic and earpiece)
 *               Falls back to MIC if VOICE_CALL is unavailable on some devices.
 *
 * Output: M4A (MPEG_4 container, AAC audio) saved to SD card or internal storage.
 */
public class CallRecordingService extends Service {

    private static final String TAG = "CallRecordingService";
    private static final String CHANNEL_ID = "call_recorder_channel";
    private static final int NOTIFICATION_ID = 1001;

    public static final String ACTION_START = "com.example.autocallrecorder.START_RECORDING";
    public static final String ACTION_STOP = "com.example.autocallrecorder.STOP_RECORDING";
    public static final String EXTRA_PHONE_NUMBER = "phone_number";
    public static final String EXTRA_DIRECTION = "call_direction";

    private MediaRecorder mediaRecorder;
    private boolean isRecording = false;
    private String currentOutputPath = null;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;

        String action = intent.getAction();
        if (ACTION_START.equals(action)) {
            String phoneNumber = intent.getStringExtra(EXTRA_PHONE_NUMBER);
            String direction = intent.getStringExtra(EXTRA_DIRECTION);
            if (phoneNumber == null) phoneNumber = "Unknown";
            if (direction == null) direction = "CALL";
            startRecording(phoneNumber, direction);

        } else if (ACTION_STOP.equals(action)) {
            stopRecording();
        }

        return START_NOT_STICKY;
    }

    private void startRecording(String phoneNumber, String direction) {
        if (isRecording) {
            Log.w(TAG, "Already recording — stopping previous before starting new");
            stopRecording();
        }

        // Build the output file path
        File outputDir = StorageUtils.getRecordingDir(this);
        if (outputDir == null) {
            Log.e(TAG, "Cannot get output directory");
            return;
        }

        String timestamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.getDefault())
                .format(new Date());

        // Resolve contact name — use it in the filename so you know who was called
        String contactName = ContactUtils.getContactName(this, phoneNumber);
        String displayName = (contactName != null) ? contactName : phoneNumber;

        // Sanitize the display name for use in a filename:
        // Replace spaces with underscores, remove characters that are invalid in filenames
        String safeName = displayName
                .replaceAll("[\\\\/:*?\"<>|]", "")   // strip invalid filename chars
                .replaceAll("\\s+", "_")               // spaces → underscores
                .replaceAll("_{2,}", "_")               // collapse multiple underscores
                .trim();
        if (safeName.isEmpty()) safeName = "Unknown";

        // Final filename: 2026-06-11_04-30-00_INCOMING_Rajesh_Kumar.m4a
        String fileName = timestamp + "_" + direction + "_" + safeName + ".m4a";
        currentOutputPath = new File(outputDir, fileName).getAbsolutePath();

        Log.d(TAG, "Starting recording: " + currentOutputPath);

        mediaRecorder = new MediaRecorder();
        try {
            // Try audio sources in order of preference:
            // VOICE_CALL = captures both sides (requires system privilege on some devices)
            // VOICE_COMMUNICATION = captures mic + earpiece processing
            // MIC = records microphone only (always works)
            boolean audioSourceSet = false;
            int[] audioSources = {
                MediaRecorder.AudioSource.VOICE_CALL,
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                MediaRecorder.AudioSource.MIC
            };
            for (int source : audioSources) {
                try {
                    mediaRecorder.setAudioSource(source);
                    Log.d(TAG, "Using audio source: " + source);
                    audioSourceSet = true;
                    break;
                } catch (Exception e) {
                    Log.w(TAG, "Audio source " + source + " not available: " + e.getMessage());
                    // reset and retry
                    mediaRecorder.reset();
                }
            }
            if (!audioSourceSet) {
                Log.e(TAG, "No audio source available!");
                cleanupRecorder();
                return;
            }

            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            mediaRecorder.setAudioSamplingRate(44100);
            mediaRecorder.setAudioEncodingBitRate(128000);
            mediaRecorder.setOutputFile(currentOutputPath);

            mediaRecorder.prepare();
            mediaRecorder.start();
            isRecording = true;

            Log.d(TAG, "Recording started successfully");

            // Start as foreground service with notification
            startForeground(NOTIFICATION_ID, buildNotification(displayName, direction));

        } catch (IOException | RuntimeException e) {
            Log.e(TAG, "Failed to start recording: " + e.getMessage(), e);
            cleanupRecorder();
        }
    }

    private void stopRecording() {
        if (!isRecording) return;

        Log.d(TAG, "Stopping recording: " + currentOutputPath);

        try {
            mediaRecorder.stop();
        } catch (RuntimeException e) {
            Log.w(TAG, "Error stopping recorder (short/empty recording?): " + e.getMessage());
            // Delete empty/corrupt file
            if (currentOutputPath != null) {
                new File(currentOutputPath).delete();
            }
        } finally {
            cleanupRecorder();
        }

        stopForeground(true);
        stopSelf();
    }

    private void cleanupRecorder() {
        if (mediaRecorder != null) {
            try {
                mediaRecorder.release();
            } catch (Exception e) {
                Log.w(TAG, "Error releasing recorder: " + e.getMessage());
            }
            mediaRecorder = null;
        }
        isRecording = false;
        currentOutputPath = null;
    }

    private Notification buildNotification(String callerName, String direction) {
        Intent notifIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, notifIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        String dirLabel = "INCOMING".equals(direction) ? "Incoming" : "Outgoing";

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_mic_on)
                .setContentTitle("📞 Recording " + dirLabel + " Call")
                .setContentText(callerName)
                .setColor(getResources().getColor(R.color.samsung_blue))
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setContentIntent(pendingIntent)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Call Recording",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Shows while a call is being recorded");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (isRecording) stopRecording();
    }
}
