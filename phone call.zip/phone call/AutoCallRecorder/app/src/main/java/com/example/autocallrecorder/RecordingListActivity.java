package com.example.autocallrecorder;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Activity that displays the list of all saved call recordings.
 * Users can play or delete recordings from this screen.
 */
public class RecordingListActivity extends AppCompatActivity
        implements RecordingAdapter.OnRecordingActionListener {

    private RecyclerView recyclerView;
    private RecordingAdapter adapter;
    private TextView tvEmpty;
    private List<File> recordingFiles = new ArrayList<>();
    private MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recording_list);

        // Setup toolbar back button
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle("Call Recordings");
        }

        recyclerView = findViewById(R.id.recycler_recordings);
        tvEmpty = findViewById(R.id.tv_empty);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadRecordings();
    }

    private void loadRecordings() {
        recordingFiles.clear();
        File dir = StorageUtils.getRecordingDir(this);
        if (dir != null && dir.exists()) {
            File[] files = dir.listFiles((d, name) -> name.endsWith(".m4a") || name.endsWith(".mp4"));
            if (files != null && files.length > 0) {
                recordingFiles.addAll(Arrays.asList(files));
                // Sort newest first
                Collections.sort(recordingFiles, new Comparator<File>() {
                    @Override
                    public int compare(File a, File b) {
                        return Long.compare(b.lastModified(), a.lastModified());
                    }
                });
            }
        }

        if (recordingFiles.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            tvEmpty.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
            adapter = new RecordingAdapter(recordingFiles, this, this);
            recyclerView.setAdapter(adapter);
        }
    }

    @Override
    public void onPlay(File file) {
        // Stop any currently playing recording
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }

        try {
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(file.getAbsolutePath());
            mediaPlayer.prepare();
            mediaPlayer.start();
            Toast.makeText(this, "Playing: " + file.getName(), Toast.LENGTH_SHORT).show();

            mediaPlayer.setOnCompletionListener(mp -> {
                mp.release();
                mediaPlayer = null;
                Toast.makeText(this, "Playback complete", Toast.LENGTH_SHORT).show();
            });
        } catch (Exception e) {
            Toast.makeText(this, "Error playing file: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onShare(File file) {
        Uri fileUri = Uri.fromFile(file);
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("audio/mp4");
        shareIntent.putExtra(Intent.EXTRA_STREAM, fileUri);
        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(shareIntent, "Share Recording"));
    }

    @Override
    public void onDelete(File file) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Recording")
                .setMessage("Delete " + file.getName() + "?")
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (file.delete()) {
                            loadRecordings();
                            Toast.makeText(RecordingListActivity.this,
                                    "Recording deleted", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(RecordingListActivity.this,
                                    "Could not delete file", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadRecordings();
    }
}
