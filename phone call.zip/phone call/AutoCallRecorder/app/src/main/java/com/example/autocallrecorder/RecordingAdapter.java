package com.example.autocallrecorder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.io.File;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * RecyclerView adapter for the recordings list.
 * Parses file names in format: yyyy-MM-dd_HH-mm-ss_DIRECTION_NUMBER.m4a
 */
public class RecordingAdapter extends RecyclerView.Adapter<RecordingAdapter.ViewHolder> {

    public interface OnRecordingActionListener {
        void onPlay(File file);
        void onShare(File file);
        void onDelete(File file);
    }

    private final List<File> files;
    private final Context context;
    private final OnRecordingActionListener listener;

    // Pattern: 2026-06-11_04-30-00_INCOMING_Rajesh_Kumar.m4a
    // Group 1=date, 2=time, 3=direction, 4=name (may contain underscores representing spaces)
    private static final Pattern FILE_PATTERN =
            Pattern.compile("(\\d{4}-\\d{2}-\\d{2})_(\\d{2}-\\d{2}-\\d{2})_(INCOMING|OUTGOING|CALL)_(.+)\\.m4a");

    public RecordingAdapter(List<File> files, Context context, OnRecordingActionListener listener) {
        this.files = files;
        this.context = context;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_recording, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        File file = files.get(position);
        holder.bind(file);
    }

    @Override
    public int getItemCount() {
        return files.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvContactName, tvDateTime, tvDirection, tvDuration, tvFileSize;
        ImageButton btnPlay, btnShare, btnDelete;

        ViewHolder(View itemView) {
            super(itemView);
            tvContactName = itemView.findViewById(R.id.tv_contact_name);
            tvDateTime = itemView.findViewById(R.id.tv_date_time);
            tvDirection = itemView.findViewById(R.id.tv_direction);
            tvDuration = itemView.findViewById(R.id.tv_duration);
            tvFileSize = itemView.findViewById(R.id.tv_file_size);
            btnPlay = itemView.findViewById(R.id.btn_play);
            btnShare = itemView.findViewById(R.id.btn_share);
            btnDelete = itemView.findViewById(R.id.btn_delete);
        }

        void bind(File file) {
            Matcher m = FILE_PATTERN.matcher(file.getName());

            if (m.matches()) {
                String date = m.group(1);
                String timeRaw = m.group(2);  // "14-30-00"
                String direction = m.group(3);
                String rawName = m.group(4);  // "Rajesh_Kumar" or "+919876543210"

                // Convert underscores back to spaces for display
                String displayNameParsed = rawName.replace("_", " ").trim();

                // Format time for display
                String time = timeRaw.replace("-", ":");

                tvContactName.setText(displayNameParsed);
                tvDateTime.setText(date + "  " + time);
                tvDirection.setText("📞 " + capitalize(direction));
                tvDirection.setTextColor(context.getResources().getColor(
                        "INCOMING".equals(direction) ? R.color.incoming_color : R.color.outgoing_color));
            } else {
                // Fallback display for unrecognized names
                tvContactName.setText(file.getName());
                tvDateTime.setText(new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                        .format(new Date(file.lastModified())));
                tvDirection.setText("📞 Call");
            }

            tvFileSize.setText(formatFileSize(file.length()));
            tvDuration.setText(""); // Duration would require MediaMetadataRetriever

            btnPlay.setOnClickListener(v -> listener.onPlay(file));
            btnShare.setOnClickListener(v -> listener.onShare(file));
            btnDelete.setOnClickListener(v -> listener.onDelete(file));
        }

        private String capitalize(String s) {
            if (s == null || s.isEmpty()) return s;
            return s.charAt(0) + s.substring(1).toLowerCase();
        }

        private String formatFileSize(long bytes) {
            DecimalFormat df = new DecimalFormat("0.0");
            if (bytes >= 1048576L) return df.format(bytes / 1048576.0) + " MB";
            return df.format(bytes / 1024.0) + " KB";
        }
    }
}
