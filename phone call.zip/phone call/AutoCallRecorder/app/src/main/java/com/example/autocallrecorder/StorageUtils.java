package com.example.autocallrecorder;

import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.util.Log;
import java.io.File;

/**
 * Utility class for SD card and recording directory management.
 *
 * KEY FIX for Samsung J2 / Android 5.x:
 * Third-party apps CANNOT write to the root of the SD card (e.g. /storage/extSdCard/).
 * They can ONLY write to:
 *   /storage/extSdCard/Android/data/<package>/files/   (app-specific external dir)
 *
 * We use Context.getExternalFilesDirs(null) which returns both:
 *   [0] = internal "external" storage (e.g. /storage/emulated/0/Android/data/<pkg>/files/)
 *   [1] = real removable SD card      (e.g. /storage/extSdCard/Android/data/<pkg>/files/)
 *
 * We prefer index [1] (real SD card) and fall back to [0] (internal).
 * No mkdirs() needed — Android creates these directories automatically.
 */
public class StorageUtils {

    private static final String TAG = "StorageUtils";
    private static final String RECORDING_FOLDER = "CallRecordings";

    /**
     * Returns the directory where recordings should be saved.
     * Prefers real removable SD card; falls back to internal external storage.
     * The directory is created if it doesn't exist.
     */
    public static File getRecordingDir(Context context) {
        File baseDir = null;

        // Try to get app-specific external directories (works on API 19+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            File[] externalDirs = context.getExternalFilesDirs(null);
            if (externalDirs != null) {
                // Prefer index 1+ (real SD card), fall back to index 0 (internal)
                for (int i = externalDirs.length - 1; i >= 0; i--) {
                    if (externalDirs[i] != null && externalDirs[i].canWrite()) {
                        baseDir = externalDirs[i];
                        Log.d(TAG, "Using external files dir [" + i + "]: " + baseDir.getAbsolutePath());
                        break;
                    }
                }
            }
        }

        // Final fallback: internal external storage
        if (baseDir == null) {
            baseDir = context.getExternalFilesDir(null);
            Log.d(TAG, "Fallback to getExternalFilesDir: " + (baseDir != null ? baseDir.getAbsolutePath() : "null"));
        }

        // Last resort: internal private storage
        if (baseDir == null) {
            baseDir = context.getFilesDir();
            Log.d(TAG, "Last resort: internal files dir: " + baseDir.getAbsolutePath());
        }

        // Create the CallRecordings subfolder
        File recordingDir = new File(baseDir, RECORDING_FOLDER);
        if (!recordingDir.exists()) {
            boolean created = recordingDir.mkdirs();
            Log.d(TAG, "mkdirs() for " + recordingDir.getAbsolutePath() + " -> " + created);
        } else {
            Log.d(TAG, "Recording dir already exists: " + recordingDir.getAbsolutePath());
        }

        // Add .nomedia to prevent recordings from showing in Gallery
        File nomedia = new File(recordingDir, ".nomedia");
        if (!nomedia.exists()) {
            try {
                nomedia.createNewFile();
            } catch (Exception ignored) {}
        }

        return recordingDir;
    }

    /**
     * Returns a human-readable display path for the UI.
     * Shows the SD card path if available, otherwise internal path.
     */
    public static String getDisplayPath(Context context) {
        File dir = getRecordingDir(context);
        if (dir != null) return dir.getAbsolutePath();
        return "Storage not available";
    }

    /**
     * Returns true if a real removable SD card is being used (not internal storage).
     */
    public static boolean isUsingSdCard(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            File[] externalDirs = context.getExternalFilesDirs(null);
            if (externalDirs != null && externalDirs.length > 1 && externalDirs[1] != null) {
                return externalDirs[1].canWrite();
            }
        }
        return false;
    }
}
