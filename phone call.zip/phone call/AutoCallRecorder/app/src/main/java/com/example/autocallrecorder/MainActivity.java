package com.example.autocallrecorder;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.StatFs;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_CODE = 100;

    private Switch switchRecording;
    private TextView tvStatus;
    private TextView tvRecordingCount;
    private TextView tvStorageInfo;
    private TextView tvSdCardPath;
    private ImageView ivStatusIcon;
    private CardView cardPermissions;
    private TextView tvPermWarning;
    private PreferencesManager prefs;

    private static final String[] REQUIRED_PERMISSIONS = {
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.PROCESS_OUTGOING_CALLS
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = new PreferencesManager(this);

        initViews();
        setupListeners();
        checkPermissions();
    }

    private void initViews() {
        switchRecording = findViewById(R.id.switch_recording);
        tvStatus = findViewById(R.id.tv_status);
        tvRecordingCount = findViewById(R.id.tv_recording_count);
        tvStorageInfo = findViewById(R.id.tv_storage_info);
        tvSdCardPath = findViewById(R.id.tv_sd_card_path);
        ivStatusIcon = findViewById(R.id.iv_status_icon);
        cardPermissions = findViewById(R.id.card_permissions);
        tvPermWarning = findViewById(R.id.tv_perm_warning);

        // Set initial state from preferences
        switchRecording.setChecked(prefs.isRecordingEnabled());
        updateStatusUI(prefs.isRecordingEnabled());
    }

    private void setupListeners() {
        switchRecording.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked && !hasAllPermissions()) {
                    switchRecording.setChecked(false);
                    Toast.makeText(MainActivity.this, 
                        "Please grant all permissions first", Toast.LENGTH_SHORT).show();
                    return;
                }
                prefs.setRecordingEnabled(isChecked);
                updateStatusUI(isChecked);
                String msg = isChecked ? "Auto call recording enabled" : "Recording disabled";
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.btn_view_recordings).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, RecordingListActivity.class));
            }
        });

        findViewById(R.id.btn_grant_permissions).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestAllPermissions();
            }
        });
    }

    private void updateStatusUI(boolean enabled) {
        if (enabled) {
            tvStatus.setText("Recording Active");
            tvStatus.setTextColor(getResources().getColor(R.color.samsung_blue));
            ivStatusIcon.setImageResource(R.drawable.ic_mic_on);
        } else {
            tvStatus.setText("Recording Paused");
            tvStatus.setTextColor(getResources().getColor(R.color.text_secondary));
            ivStatusIcon.setImageResource(R.drawable.ic_mic_off);
        }
    }

    private void updateStorageInfo() {
        // Use the new writable recording directory path
        File recordingDir = StorageUtils.getRecordingDir(this);
        if (recordingDir != null) {
            tvSdCardPath.setText(recordingDir.getAbsolutePath());
            try {
                StatFs stat = new StatFs(recordingDir.getPath());
                long bytesAvailable = stat.getAvailableBlocksLong() * stat.getBlockSizeLong();
                long bytesTotal = stat.getBlockCountLong() * stat.getBlockSizeLong();
                String sdLabel = StorageUtils.isUsingSdCard(this) ? "SD Card" : "Internal";
                tvStorageInfo.setText(sdLabel + " — Free: " + formatSize(bytesAvailable) + " / " + formatSize(bytesTotal));
            } catch (Exception e) {
                tvStorageInfo.setText("Storage info unavailable");
            }
        } else {
            tvSdCardPath.setText("Storage not available");
            tvStorageInfo.setText("Cannot access storage");
        }
    }

    private void updateRecordingCount() {
        File recordingsDir = StorageUtils.getRecordingDir(this);
        if (recordingsDir != null && recordingsDir.exists()) {
            File[] files = recordingsDir.listFiles();
            int count = (files != null) ? files.length : 0;
            tvRecordingCount.setText(count + " recording" + (count != 1 ? "s" : "") + " saved");
        } else {
            tvRecordingCount.setText("No recordings yet");
        }
    }

    private String formatSize(long bytes) {
        DecimalFormat df = new DecimalFormat("0.0");
        if (bytes >= 1073741824L) return df.format(bytes / 1073741824.0) + " GB";
        if (bytes >= 1048576L) return df.format(bytes / 1048576.0) + " MB";
        return df.format(bytes / 1024.0) + " KB";
    }

    private boolean hasAllPermissions() {
        for (String perm : REQUIRED_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    private void checkPermissions() {
        if (hasAllPermissions()) {
            cardPermissions.setVisibility(View.GONE);
        } else {
            cardPermissions.setVisibility(View.VISIBLE);
        }
        updateStorageInfo();
        updateRecordingCount();
    }

    private void requestAllPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            List<String> missing = new ArrayList<>();
            for (String perm : REQUIRED_PERMISSIONS) {
                if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                    missing.add(perm);
                }
            }
            if (!missing.isEmpty()) {
                ActivityCompat.requestPermissions(this,
                        missing.toArray(new String[0]), PERMISSION_REQUEST_CODE);
            }
        }
        // Android 5.0 (API 21): permissions granted at install time automatically
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (hasAllPermissions()) {
                cardPermissions.setVisibility(View.GONE);
                Toast.makeText(this, "All permissions granted!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Some permissions were denied. Recording may not work.", 
                    Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStorageInfo();
        updateRecordingCount();
        checkPermissions();
    }
}
