package com.example.whatsappcallrecorder;

import android.app.AlertDialog;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class RecordingListActivity extends AppCompatActivity
        implements RecordingAdapter.OnRecordingActionListener {

    private RecyclerView recyclerView;
    private RecordingAdapter adapter;
    private TextView tvEmpty;
    private List<File> files = new ArrayList<>();
    private MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recording_list);
        ActionBar ab = getSupportActionBar();
        if (ab != null) { ab.setDisplayHomeAsUpEnabled(true); ab.setTitle("WA Call Recordings"); }
        recyclerView = findViewById(R.id.recycler_recordings);
        tvEmpty      = findViewById(R.id.tv_empty);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadRecordings();
    }

    private void loadRecordings() {
        files.clear();
        File dir = StorageUtils.getRecordingDir(this);
        if (dir != null && dir.exists()) {
            File[] arr = dir.listFiles(f -> f.getName().endsWith(".m4a"));
            if (arr != null && arr.length > 0) {
                files.addAll(Arrays.asList(arr));
                Collections.sort(files, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
            }
        }
        if (files.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            tvEmpty.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
            adapter = new RecordingAdapter(files, this, this);
            recyclerView.setAdapter(adapter);
        }
    }

    @Override
    public void onPlay(File file) {
        if (mediaPlayer != null) { mediaPlayer.release(); mediaPlayer = null; }
        try {
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(file.getAbsolutePath());
            mediaPlayer.prepare();
            mediaPlayer.start();
            Toast.makeText(this, "▶ Playing: " + file.getName(), Toast.LENGTH_SHORT).show();
            mediaPlayer.setOnCompletionListener(mp -> { mp.release(); mediaPlayer = null; });
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onShare(File file) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("audio/mp4");
        i.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, "Share Recording"));
    }

    @Override
    public void onDelete(File file) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Recording")
                .setMessage("Delete " + file.getName() + "?")
                .setPositiveButton("Delete", (d, w) -> {
                    if (file.delete()) { loadRecordings(); Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show(); }
                })
                .setNegativeButton("Cancel", null).show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { onBackPressed(); return true; }
        return super.onOptionsItemSelected(item);
    }

    @Override protected void onResume() { super.onResume(); loadRecordings(); }
    @Override protected void onDestroy() { super.onDestroy(); if (mediaPlayer != null) { mediaPlayer.release(); } }
}
