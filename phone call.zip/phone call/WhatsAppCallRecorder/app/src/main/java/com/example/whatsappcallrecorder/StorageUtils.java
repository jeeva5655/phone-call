package com.example.whatsappcallrecorder;

import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.util.Log;
import java.io.File;

public class StorageUtils {
    private static final String TAG = "StorageUtils";
    private static final String FOLDER = "WACallRecordings";

    public static File getRecordingDir(Context context) {
        File baseDir = null;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            File[] dirs = context.getExternalFilesDirs(null);
            if (dirs != null) {
                for (int i = dirs.length - 1; i >= 0; i--) {
                    if (dirs[i] != null && dirs[i].canWrite()) {
                        baseDir = dirs[i];
                        Log.d(TAG, "Using external dir[" + i + "]: " + baseDir);
                        break;
                    }
                }
            }
        }

        if (baseDir == null) baseDir = context.getExternalFilesDir(null);
        if (baseDir == null) baseDir = context.getFilesDir();

        File dir = new File(baseDir, FOLDER);
        if (!dir.exists()) {
            boolean ok = dir.mkdirs();
            Log.d(TAG, "mkdirs " + dir + " -> " + ok);
        }

        File nomedia = new File(dir, ".nomedia");
        if (!nomedia.exists()) { try { nomedia.createNewFile(); } catch (Exception ignored) {} }

        return dir;
    }

    public static boolean isUsingSdCard(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            File[] dirs = context.getExternalFilesDirs(null);
            return dirs != null && dirs.length > 1 && dirs[1] != null && dirs[1].canWrite();
        }
        return false;
    }
}
