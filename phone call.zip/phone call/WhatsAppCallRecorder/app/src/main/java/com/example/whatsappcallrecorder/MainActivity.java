package com.example.whatsappcallrecorder;

import android.Manifest;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.StatFs;
import android.provider.Settings;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_CODE = 100;

    private Switch switchRecording;
    private TextView tvStatus;
    private TextView tvRecordingCount;
    private TextView tvStorageInfo;
    private TextView tvSavePath;
    private ImageView ivStatusIcon;
    private CardView cardAccessibility;
    private CardView cardPermissions;
    private PreferencesManager prefs;

    private static final String[] REQUIRED_PERMISSIONS = {
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.READ_CONTACTS
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = new PreferencesManager(this);
        initViews();
        setupListeners();
    }

    private void initViews() {
        switchRecording = findViewById(R.id.switch_recording);
        tvStatus        = findViewById(R.id.tv_status);
        tvRecordingCount = findViewById(R.id.tv_recording_count);
        tvStorageInfo   = findViewById(R.id.tv_storage_info);
        tvSavePath      = findViewById(R.id.tv_save_path);
        ivStatusIcon    = findViewById(R.id.iv_status_icon);
        cardAccessibility = findViewById(R.id.card_accessibility);
        cardPermissions   = findViewById(R.id.card_permissions);

        switchRecording.setChecked(prefs.isRecordingEnabled());
        updateStatusUI(prefs.isRecordingEnabled());
    }

    private void setupListeners() {
        switchRecording.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton btn, boolean checked) {
                if (checked && !isAccessibilityEnabled()) {
                    switchRecording.setChecked(false);
                    Toast.makeText(MainActivity.this,
                            "Please enable Accessibility Service first", Toast.LENGTH_SHORT).show();
                    return;
                }
                prefs.setRecordingEnabled(checked);
                updateStatusUI(checked);
            }
        });

        findViewById(R.id.btn_enable_accessibility).setOnClickListener(v -> openAccessibilitySettings());
        findViewById(R.id.btn_grant_permissions).setOnClickListener(v -> requestAllPermissions());
        findViewById(R.id.btn_view_recordings).setOnClickListener(v ->
                startActivity(new Intent(this, RecordingListActivity.class)));
    }

    private void updateStatusUI(boolean enabled) {
        if (enabled && isAccessibilityEnabled()) {
            tvStatus.setText("Recording Active");
            tvStatus.setTextColor(getResources().getColor(R.color.whatsapp_green));
            ivStatusIcon.setImageResource(R.drawable.ic_mic_on);
        } else if (enabled && !isAccessibilityEnabled()) {
            tvStatus.setText("Needs Accessibility Permission");
            tvStatus.setTextColor(getResources().getColor(R.color.warning_orange));
            ivStatusIcon.setImageResource(R.drawable.ic_mic_off);
        } else {
            tvStatus.setText("Recording Paused");
            tvStatus.setTextColor(getResources().getColor(R.color.text_secondary));
            ivStatusIcon.setImageResource(R.drawable.ic_mic_off);
        }
    }

    private boolean isAccessibilityEnabled() {
        AccessibilityManager am = (AccessibilityManager)
                getSystemService(Context.ACCESSIBILITY_SERVICE);
        if (am == null) return false;
        List<AccessibilityServiceInfo> enabledServices =
                am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        for (AccessibilityServiceInfo info : enabledServices) {
            ServiceInfo si = info.getResolveInfo().serviceInfo;
            if (getPackageName().equals(si.packageName) &&
                    WhatsAppCallDetector.class.getName().equals(si.name)) {
                return true;
            }
        }
        return false;
    }

    private void openAccessibilitySettings() {
        Toast.makeText(this,
                "Find 'WhatsApp Call Recorder' and turn it ON",
                Toast.LENGTH_LONG).show();
        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
    }

    private boolean hasAllPermissions() {
        for (String p : REQUIRED_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED)
                return false;
        }
        return true;
    }

    private void requestAllPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            List<String> missing = new ArrayList<>();
            for (String p : REQUIRED_PERMISSIONS) {
                if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED)
                    missing.add(p);
            }
            if (!missing.isEmpty())
                ActivityCompat.requestPermissions(this,
                        missing.toArray(new String[0]), PERMISSION_REQUEST_CODE);
        }
    }

    private void updateStorageInfo() {
        File dir = StorageUtils.getRecordingDir(this);
        if (dir != null) {
            tvSavePath.setText(dir.getAbsolutePath());
            try {
                StatFs stat = new StatFs(dir.getPath());
                long free = stat.getAvailableBlocksLong() * stat.getBlockSizeLong();
                long total = stat.getBlockCountLong() * stat.getBlockSizeLong();
                String label = StorageUtils.isUsingSdCard(this) ? "SD Card" : "Internal";
                tvStorageInfo.setText(label + " — Free: " + fmtSize(free) + " / " + fmtSize(total));
            } catch (Exception e) {
                tvStorageInfo.setText("Storage info unavailable");
            }
        }
    }

    private void updateRecordingCount() {
        File dir = StorageUtils.getRecordingDir(this);
        if (dir != null && dir.exists()) {
            File[] files = dir.listFiles(f -> f.getName().endsWith(".m4a"));
            int count = files != null ? files.length : 0;
            tvRecordingCount.setText(count + " recording" + (count != 1 ? "s" : "") + " saved");
        } else {
            tvRecordingCount.setText("No recordings yet");
        }
    }

    private String fmtSize(long bytes) {
        DecimalFormat df = new DecimalFormat("0.0");
        if (bytes >= 1073741824L) return df.format(bytes / 1073741824.0) + " GB";
        if (bytes >= 1048576L)    return df.format(bytes / 1048576.0) + " MB";
        return df.format(bytes / 1024.0) + " KB";
    }

    @Override
    public void onRequestPermissionsResult(int code, @NonNull String[] perms,
                                           @NonNull int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == PERMISSION_REQUEST_CODE) {
            if (hasAllPermissions()) {
                cardPermissions.setVisibility(View.GONE);
                Toast.makeText(this, "All permissions granted!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Accessibility card
        if (isAccessibilityEnabled()) {
            cardAccessibility.setVisibility(View.GONE);
        } else {
            cardAccessibility.setVisibility(View.VISIBLE);
        }
        // Permissions card
        cardPermissions.setVisibility(hasAllPermissions() ? View.GONE : View.VISIBLE);

        updateStatusUI(prefs.isRecordingEnabled());
        updateStorageInfo();
        updateRecordingCount();
    }
}
