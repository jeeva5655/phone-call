package com.example.whatsappcallrecorder;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Core of the WhatsApp call detection mechanism.
 *
 * How it works:
 * Android fires accessibility events whenever a window changes on screen.
 * We filter only WhatsApp events and look for patterns that indicate
 * a voice/video call is in progress.
 *
 * WhatsApp call screen indicators (stable across WhatsApp versions):
 * - View IDs containing "call" in the WhatsApp package
 * - Content descriptions like "End call", "Mute", "Speaker"
 * - Class names of the call activity
 *
 * We maintain a simple state machine:
 *   IDLE → IN_CALL (when call screen detected) → IDLE (when call screen gone)
 */
public class WhatsAppCallDetector extends AccessibilityService {

    private static final String TAG = "WhatsAppCallDetector";

    // WhatsApp package names (consumer + Business)
    private static final Set<String> WHATSAPP_PACKAGES = new HashSet<>(Arrays.asList(
            "com.whatsapp",
            "com.whatsapp.w4b"
    ));

    // Keywords in content-descriptions / view text that indicate an active call screen
    // These are stable across WhatsApp versions because they are user-visible strings
    private static final Set<String> CALL_SCREEN_KEYWORDS = new HashSet<>(Arrays.asList(
            "end call", "mute", "speaker", "video", "calling", "ringing",
            "voice call", "whatsapp call", "ongoing call", "in call",
            // Tamil/Hindi/regional WhatsApp labels may differ — fallback to class name
            "hang up", "flip camera", "switch camera"
    ));

    // WhatsApp activity class names that correspond to call screens
    private static final Set<String> CALL_ACTIVITY_CLASSES = new HashSet<>(Arrays.asList(
            "com.whatsapp.voipcalling.VoipActivityV2",
            "com.whatsapp.voipcalling.VoipActivity",
            "com.whatsapp.VoipActivity",
            "com.whatsapp.calling.CallActivity",
            "com.whatsapp.calls.activity.CallActivity"
    ));

    private boolean isCallActive = false;
    private String lastActivePackage = "";

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        String packageName = event.getPackageName() != null
                ? event.getPackageName().toString() : "";

        // Only process WhatsApp events
        if (!WHATSAPP_PACKAGES.contains(packageName)) {
            // If we were in a WhatsApp call and moved away from WhatsApp entirely
            if (isCallActive && !packageName.isEmpty() && !packageName.equals(lastActivePackage)) {
                // Wait briefly — user may have switched apps mid-call
                // Don't stop yet based on package alone
            }
            return;
        }

        lastActivePackage = packageName;
        int eventType = event.getEventType();

        if (eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            String className = event.getClassName() != null
                    ? event.getClassName().toString() : "";

            Log.d(TAG, "Window changed: " + className + " pkg=" + packageName);

            // Check if this is a known call activity class
            boolean isCallClass = CALL_ACTIVITY_CLASSES.contains(className)
                    || className.toLowerCase().contains("voip")
                    || className.toLowerCase().contains("call");

            if (isCallClass && !isCallActive) {
                Log.d(TAG, "Call screen detected via class: " + className);
                onCallStarted(packageName);
            } else if (!isCallClass && isCallActive) {
                // Moved to a non-call screen within WhatsApp — call ended
                Log.d(TAG, "Left call screen, call ended");
                onCallEnded();
            }
        }

        if (eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                || eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            // Scan the window content for call indicators
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null) {
                boolean callIndicatorFound = scanNodeForCallIndicators(root);
                root.recycle();

                if (callIndicatorFound && !isCallActive) {
                    Log.d(TAG, "Call screen detected via content scan");
                    onCallStarted(packageName);
                } else if (!callIndicatorFound && isCallActive) {
                    // Double-check: only stop if we're sure the call ended
                    // (content scan can be momentarily empty during transitions)
                    Log.d(TAG, "No call indicators found — call may have ended");
                    // We use a small delay approach: we'll let the next state change confirm
                }
            }
        }
    }

    /**
     * Recursively scans the accessibility node tree for call-related content.
     * Returns true if call screen indicators are found.
     */
    private boolean scanNodeForCallIndicators(AccessibilityNodeInfo node) {
        if (node == null) return false;

        // Check content description
        CharSequence desc = node.getContentDescription();
        if (desc != null) {
            String descLower = desc.toString().toLowerCase();
            for (String keyword : CALL_SCREEN_KEYWORDS) {
                if (descLower.contains(keyword)) {
                    Log.d(TAG, "Call keyword found in content-desc: " + desc);
                    return true;
                }
            }
        }

        // Check view ID resource name
        String viewId = node.getViewIdResourceName();
        if (viewId != null) {
            String viewIdLower = viewId.toLowerCase();
            if (viewIdLower.contains("end_call") || viewIdLower.contains("endcall")
                    || viewIdLower.contains("mute") || viewIdLower.contains("hang_up")
                    || viewIdLower.contains("voip") || viewIdLower.contains("call_btn")) {
                Log.d(TAG, "Call keyword found in viewId: " + viewId);
                return true;
            }
        }

        // Recurse into children
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                if (scanNodeForCallIndicators(child)) {
                    child.recycle();
                    return true;
                }
                child.recycle();
            }
        }
        return false;
    }

    private void onCallStarted(String packageName) {
        if (isCallActive) return;
        isCallActive = true;

        PreferencesManager prefs = new PreferencesManager(this);
        if (!prefs.isRecordingEnabled()) {
            Log.d(TAG, "Recording disabled by user — skipping");
            return;
        }

        Log.d(TAG, "WhatsApp call STARTED — beginning recording");
        String appLabel = "com.whatsapp.w4b".equals(packageName)
                ? "WhatsApp Business" : "WhatsApp";

        Intent serviceIntent = new Intent(this, CallRecordingService.class);
        serviceIntent.setAction(CallRecordingService.ACTION_START);
        serviceIntent.putExtra(CallRecordingService.EXTRA_APP_LABEL, appLabel);
        startService(serviceIntent);
    }

    private void onCallEnded() {
        if (!isCallActive) return;
        isCallActive = false;

        Log.d(TAG, "WhatsApp call ENDED — stopping recording");

        Intent serviceIntent = new Intent(this, CallRecordingService.class);
        serviceIntent.setAction(CallRecordingService.ACTION_STOP);
        startService(serviceIntent);
    }

    @Override
    public void onInterrupt() {
        Log.d(TAG, "Accessibility service interrupted");
        if (isCallActive) {
            onCallEnded();
        }
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        Log.d(TAG, "WhatsApp Call Detector connected");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (isCallActive) {
            onCallEnded();
        }
    }
}
