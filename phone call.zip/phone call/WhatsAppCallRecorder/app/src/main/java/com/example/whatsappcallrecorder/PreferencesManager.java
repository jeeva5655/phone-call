package com.example.whatsappcallrecorder;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferencesManager {
    private static final String PREF_NAME = "wacr_prefs";
    private static final String KEY_ENABLED = "recording_enabled";
    private final SharedPreferences prefs;

    public PreferencesManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public boolean isRecordingEnabled() {
        return prefs.getBoolean(KEY_ENABLED, true);
    }

    public void setRecordingEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_ENABLED, enabled).apply();
    }
}
