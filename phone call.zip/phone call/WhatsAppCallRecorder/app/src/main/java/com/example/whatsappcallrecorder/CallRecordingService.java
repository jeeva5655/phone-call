package com.example.whatsappcallrecorder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Foreground service that records audio during a WhatsApp call.
 *
 * Audio source priority (best for WhatsApp VoIP):
 *   1. VOICE_COMMUNICATION — optimized for VoIP, may capture both sides on some devices
 *   2. MIC — always works, captures your microphone clearly
 *
 * Note: VOICE_CALL is for cellular calls and does NOT work for WhatsApp.
 */
public class CallRecordingService extends Service {

    private static final String TAG = "CallRecordingService";
    private static final String CHANNEL_ID = "wa_recorder_channel";
    private static final int NOTIFICATION_ID = 2001;

    public static final String ACTION_START = "com.example.whatsappcallrecorder.START";
    public static final String ACTION_STOP  = "com.example.whatsappcallrecorder.STOP";
    public static final String EXTRA_APP_LABEL = "app_label";

    private MediaRecorder mediaRecorder;
    private boolean isRecording = false;
    private String currentOutputPath = null;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();

        if (ACTION_START.equals(action)) {
            String appLabel = intent.getStringExtra(EXTRA_APP_LABEL);
            if (appLabel == null) appLabel = "WhatsApp";
            startRecording(appLabel);
        } else if (ACTION_STOP.equals(action)) {
            stopRecording();
        }
        return START_NOT_STICKY;
    }

    private void startRecording(String appLabel) {
        if (isRecording) {
            Log.w(TAG, "Already recording — ignoring duplicate start");
            return;
        }

        File outputDir = StorageUtils.getRecordingDir(this);
        if (outputDir == null) {
            Log.e(TAG, "No output directory available");
            return;
        }

        String timestamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.getDefault())
                .format(new Date());

        // We don't know the contact name at this point (WhatsApp doesn't expose it via
        // accessibility events reliably). We use a placeholder and rename on stop if possible.
        String fileName = timestamp + "_WhatsApp_Call.m4a";
        currentOutputPath = new File(outputDir, fileName).getAbsolutePath();

        Log.d(TAG, "Starting WhatsApp recording: " + currentOutputPath);

        mediaRecorder = new MediaRecorder();
        try {
            // For WhatsApp VoIP calls:
            // VOICE_COMMUNICATION is the correct source — designed for VoIP apps
            // On Android 5-7 and some Samsung devices it captures both mic + speaker
            // On Android 8+ it captures mic only (system restriction, not our bug)
            boolean sourceSet = false;
            int[] sources = {
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                MediaRecorder.AudioSource.MIC
            };
            for (int source : sources) {
                try {
                    mediaRecorder.setAudioSource(source);
                    Log.d(TAG, "Audio source set: " + source);
                    sourceSet = true;
                    break;
                } catch (Exception e) {
                    Log.w(TAG, "Source " + source + " failed: " + e.getMessage());
                    mediaRecorder.reset();
                }
            }
            if (!sourceSet) {
                Log.e(TAG, "No usable audio source found");
                cleanupRecorder();
                return;
            }

            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            mediaRecorder.setAudioSamplingRate(44100);
            mediaRecorder.setAudioEncodingBitRate(128000);
            mediaRecorder.setOutputFile(currentOutputPath);
            mediaRecorder.prepare();
            mediaRecorder.start();
            isRecording = true;

            Log.d(TAG, "Recording started successfully");
            startForeground(NOTIFICATION_ID, buildNotification(appLabel));

        } catch (Exception e) {
            Log.e(TAG, "Failed to start recording: " + e.getMessage(), e);
            cleanupRecorder();
        }
    }

    private void stopRecording() {
        if (!isRecording) return;
        Log.d(TAG, "Stopping recording");

        try {
            mediaRecorder.stop();
        } catch (RuntimeException e) {
            Log.w(TAG, "Error stopping (empty recording?): " + e.getMessage());
            if (currentOutputPath != null) new File(currentOutputPath).delete();
        } finally {
            cleanupRecorder();
        }

        stopForeground(true);
        stopSelf();
    }

    private void cleanupRecorder() {
        if (mediaRecorder != null) {
            try { mediaRecorder.release(); } catch (Exception ignored) {}
            mediaRecorder = null;
        }
        isRecording = false;
        currentOutputPath = null;
    }

    private Notification buildNotification(String appLabel) {
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_mic_on)
                .setContentTitle("🟢 Recording " + appLabel + " Call")
                .setContentText("Tap to open recorder")
                .setColor(getResources().getColor(R.color.whatsapp_green))
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setContentIntent(pi)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "WhatsApp Call Recording",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Active while recording a WhatsApp call");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    @Nullable @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (isRecording) stopRecording();
    }
}
