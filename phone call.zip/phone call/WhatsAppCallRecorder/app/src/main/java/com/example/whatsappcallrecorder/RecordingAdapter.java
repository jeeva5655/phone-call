package com.example.whatsappcallrecorder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.io.File;
import java.text.DecimalFormat;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RecordingAdapter extends RecyclerView.Adapter<RecordingAdapter.ViewHolder> {

    public interface OnRecordingActionListener {
        void onPlay(File file);
        void onShare(File file);
        void onDelete(File file);
    }

    // Filename format: yyyy-MM-dd_HH-mm-ss_WhatsApp_Call.m4a
    private static final Pattern FILE_PATTERN =
            Pattern.compile("(\\d{4}-\\d{2}-\\d{2})_(\\d{2}-\\d{2}-\\d{2})_(.+)\\.m4a");

    private final List<File> files;
    private final Context context;
    private final OnRecordingActionListener listener;

    public RecordingAdapter(List<File> files, Context context, OnRecordingActionListener listener) {
        this.files    = files;
        this.context  = context;
        this.listener = listener;
    }

    @NonNull @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_recording, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int pos) {
        File file = files.get(pos);
        Matcher m = FILE_PATTERN.matcher(file.getName());
        if (m.matches()) {
            String date    = m.group(1);
            String timeRaw = m.group(2);
            String label   = m.group(3).replace("_", " ");
            h.tvLabel.setText(label);
            h.tvDateTime.setText(date + "  " + timeRaw.replace("-", ":"));
        } else {
            h.tvLabel.setText(file.getName());
            h.tvDateTime.setText("");
        }
        h.tvSize.setText(formatSize(file.length()));
        h.btnPlay.setOnClickListener(v -> listener.onPlay(file));
        h.btnShare.setOnClickListener(v -> listener.onShare(file));
        h.btnDelete.setOnClickListener(v -> listener.onDelete(file));
    }

    @Override public int getItemCount() { return files.size(); }

    private String formatSize(long b) {
        DecimalFormat df = new DecimalFormat("0.0");
        if (b >= 1048576) return df.format(b / 1048576.0) + " MB";
        return df.format(b / 1024.0) + " KB";
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvLabel, tvDateTime, tvSize;
        ImageButton btnPlay, btnShare, btnDelete;
        ViewHolder(View v) {
            super(v);
            tvLabel    = v.findViewById(R.id.tv_contact_name);
            tvDateTime = v.findViewById(R.id.tv_date_time);
            tvSize     = v.findViewById(R.id.tv_file_size);
            btnPlay    = v.findViewById(R.id.btn_play);
            btnShare   = v.findViewById(R.id.btn_share);
            btnDelete  = v.findViewById(R.id.btn_delete);
        }
    }
}
